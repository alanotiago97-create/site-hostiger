
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import pb from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Plus, Edit, Trash2, Search, Package } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import ProductUpload from '@/components/ProductUpload.jsx';

const CadastroPage = () => {
  const { toast } = useToast();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingProduct, setEditingProduct] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);

  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    category: 'Masculino',
    volume: '',
    costPrice: '',
    salePrice: '',
    stockQuantity: '',
    internalCode: '',
  });

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const data = await pb.collection('products').getFullList({
        sort: '-created',
        $autoCancel: false,
      });
      setProducts(data);
    } catch (error) {
      console.error('Error loading products:', error);
      toast({ title: 'Erro', description: 'Falha ao carregar produtos', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const calculateProfitMargin = () => {
    const cost = parseFloat(formData.costPrice) || 0;
    const sale = parseFloat(formData.salePrice) || 0;
    if (cost <= 0) return 0;
    return ((sale - cost) / cost * 100).toFixed(2);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const cost = parseFloat(formData.costPrice);
    const sale = parseFloat(formData.salePrice);
    const stock = parseInt(formData.stockQuantity);

    if (cost < 0 || sale < 0 || stock < 0) {
      toast({ title: 'Erro', description: 'Valores não podem ser negativos', variant: 'destructive' });
      return;
    }

    setIsSubmitting(true);
    try {
      const pbFormData = new FormData();
      pbFormData.append('name', formData.name);
      if (formData.brand) pbFormData.append('brand', formData.brand);
      pbFormData.append('category', formData.category);
      if (formData.volume) pbFormData.append('volume', formData.volume);
      pbFormData.append('costPrice', cost);
      pbFormData.append('salePrice', sale);
      pbFormData.append('stockQuantity', stock);
      if (formData.internalCode) pbFormData.append('internalCode', formData.internalCode);
      pbFormData.append('profitMargin', parseFloat(calculateProfitMargin()));

      if (selectedImage) {
        pbFormData.append('image', selectedImage);
      }

      if (editingProduct) {
        await pb.collection('products').update(editingProduct.id, pbFormData, { $autoCancel: false });
        toast({ title: 'Sucesso', description: 'Produto atualizado com sucesso' });
      } else {
        await pb.collection('products').create(pbFormData, { $autoCancel: false });
        toast({ title: 'Sucesso', description: 'Produto cadastrado com sucesso' });
      }

      resetForm();
      loadProducts();
    } catch (error) {
      console.error('Error saving product:', error);
      toast({ title: 'Erro', description: 'Falha ao salvar produto', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '', brand: '', category: 'Masculino', volume: '',
      costPrice: '', salePrice: '', stockQuantity: '', internalCode: '',
    });
    setEditingProduct(null);
    setSelectedImage(null);
  };

  const handleEdit = (product) => {
    setFormData({
      name: product.name,
      brand: product.brand || '',
      category: product.category,
      volume: product.volume || '',
      costPrice: product.costPrice.toString(),
      salePrice: product.salePrice.toString(),
      stockQuantity: product.stockQuantity.toString(),
      internalCode: product.internalCode || '',
    });
    setEditingProduct(product);
    setSelectedImage(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Deseja realmente excluir este produto?')) return;

    try {
      await pb.collection('products').delete(id, { $autoCancel: false });
      toast({ title: 'Sucesso', description: 'Produto excluído com sucesso' });
      loadProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
      toast({ title: 'Erro', description: 'Falha ao excluir produto', variant: 'destructive' });
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (product.brand && product.brand.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (product.internalCode && product.internalCode.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f5f7fa] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4a7ba7]"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Cadastro de Produtos - Dagostim Importados</title>
        <meta name="description" content="Gerenciamento de produtos e estoque" />
      </Helmet>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#1a3a3a]">Cadastro de Produtos</h1>
          <p className="text-[#7f8c8d] mt-1">Gerencie seu inventário e preços</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden sticky top-24">
              <div className="p-6 border-b border-gray-100 bg-gray-50/50">
                <h2 className="text-xl font-bold text-[#1a3a3a] flex items-center gap-2">
                  <Package className="h-5 w-5 text-[#4a7ba7]" />
                  {editingProduct ? 'Editar Produto' : 'Novo Produto'}
                </h2>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                <ProductUpload 
                  onImageChange={setSelectedImage} 
                  initialImage={editingProduct?.image ? pb.files.getUrl(editingProduct, editingProduct.image) : null} 
                />

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Nome *</label>
                  <input type="text" name="name" value={formData.name} onChange={handleInputChange} required className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Marca</label>
                  <input type="text" name="brand" value={formData.brand} onChange={handleInputChange} className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Categoria *</label>
                  <select name="category" value={formData.category} onChange={handleInputChange} required className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]">
                    <option value="Masculino">Masculino</option>
                    <option value="Feminino">Feminino</option>
                    <option value="Unissex">Unissex</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Volume</label>
                  <input type="text" name="volume" value={formData.volume} onChange={handleInputChange} placeholder="Ex: 100ml" className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#2c3e50] mb-2">Preço Custo *</label>
                    <input type="number" name="costPrice" value={formData.costPrice} onChange={handleInputChange} step="0.01" min="0" required className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#2c3e50] mb-2">Preço Venda *</label>
                    <input type="number" name="salePrice" value={formData.salePrice} onChange={handleInputChange} step="0.01" min="0" required className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                  </div>
                </div>

                {formData.costPrice && formData.salePrice && (
                  <div className="bg-[#2ecc71]/10 border border-[#2ecc71]/30 rounded-lg p-3">
                    <p className="text-sm text-[#2c3e50]">Margem de Lucro:</p>
                    <p className="text-2xl font-bold text-[#2ecc71]">{calculateProfitMargin()}%</p>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Quantidade em Estoque *</label>
                  <input type="number" name="stockQuantity" value={formData.stockQuantity} onChange={handleInputChange} min="0" required className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Código Interno/SKU</label>
                  <input type="text" name="internalCode" value={formData.internalCode} onChange={handleInputChange} className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div className="flex gap-2 pt-2">
                  <Button type="submit" disabled={isSubmitting} className="flex-1 bg-[#4a7ba7] hover:bg-[#3a6b97] text-white shadow-md">
                    {isSubmitting ? 'Salvando...' : (editingProduct ? 'Atualizar' : 'Cadastrar')}
                  </Button>
                  {editingProduct && (
                    <Button type="button" onClick={resetForm} variant="outline" className="border-[#4a7ba7] text-[#4a7ba7] hover:bg-[#4a7ba7]/10">
                      Cancelar
                    </Button>
                  )}
                </div>
              </form>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col md:flex-row justify-between items-center gap-4">
                <h2 className="text-xl font-bold text-[#1a3a3a]">Produtos Cadastrados</h2>
                <div className="relative w-full md:w-64">
                  <input type="text" placeholder="Buscar produtos..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                </div>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredProducts.length === 0 ? (
                    <p className="text-[#7f8c8d] col-span-2 text-center py-8">Nenhum produto encontrado</p>
                  ) : (
                    filteredProducts.map((product) => (
                      <div key={product.id} className={`p-4 rounded-lg border transition-all hover:shadow-md ${product.stockQuantity === 0 ? 'bg-red-50 border-red-200' : product.stockQuantity < 10 ? 'bg-[#f39c12]/5 border-[#f39c12]/30' : 'bg-white border-gray-100'}`}>
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex gap-3">
                            {product.image ? (
                              <img src={pb.files.getUrl(product, product.image)} alt={product.name} className="w-12 h-12 rounded-md object-cover border border-gray-200" />
                            ) : (
                              <div className="w-12 h-12 rounded-md bg-gray-100 flex items-center justify-center border border-gray-200">
                                <Package className="w-6 h-6 text-gray-400" />
                              </div>
                            )}
                            <div>
                              <h3 className="text-[#1a3a3a] font-bold text-lg leading-tight">{product.name}</h3>
                              <div className="flex items-center gap-2 mt-1">
                                {product.brand && <span className="text-[#7f8c8d] text-xs bg-gray-100 px-2 py-0.5 rounded-full">{product.brand}</span>}
                                <span className="text-[#7f8c8d] text-xs bg-gray-100 px-2 py-0.5 rounded-full">{product.category}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button onClick={() => handleEdit(product)} className="text-[#4a7ba7] hover:text-[#3a6b97] p-1.5 hover:bg-[#4a7ba7]/10 rounded-full transition-colors"><Edit className="h-4 w-4" /></button>
                            <button onClick={() => handleDelete(product.id)} className="text-red-500 hover:text-red-700 p-1.5 hover:bg-red-50 rounded-full transition-colors"><Trash2 className="h-4 w-4" /></button>
                          </div>
                        </div>

                        <div className="space-y-2 text-sm border-t border-gray-100 pt-3 mt-2">
                          <div className="flex justify-between">
                            <span className="text-[#7f8c8d]">Preço:</span>
                            <span className="text-[#1a3a3a] font-bold text-lg">{formatCurrency(product.salePrice)}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-[#7f8c8d]">Estoque:</span>
                            <span className={`font-bold px-2 py-0.5 rounded-full text-xs ${product.stockQuantity === 0 ? 'bg-red-100 text-red-600' : product.stockQuantity < 10 ? 'bg-[#f39c12]/20 text-[#f39c12]' : 'bg-[#2ecc71]/20 text-[#2ecc71]'}`}>
                              {product.stockQuantity} un.
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[#7f8c8d]">Margem:</span>
                            <span className="text-[#2ecc71] font-medium">{product.profitMargin?.toFixed(2)}%</span>
                          </div>
                          {product.internalCode && (
                            <div className="flex justify-between items-center">
                              <span className="text-[#7f8c8d]">SKU:</span>
                              <span className="text-[#7f8c8d] font-mono text-xs bg-gray-100 px-2 py-0.5 rounded">{product.internalCode}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default CadastroPage;
