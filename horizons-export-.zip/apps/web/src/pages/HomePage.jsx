const HomePage = () => {
    return (
        <div>
        </div>
    )
}

export default HomePage;