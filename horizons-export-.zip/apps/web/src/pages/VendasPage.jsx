import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Plus, Trash2, X, Printer, ShoppingCart, CreditCard, User, Package } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import CreditPaymentForm from '@/components/CreditPaymentForm.jsx';
import { createCredit } from '@/services/creditService.js';
import WhatsAppAlert from '@/components/WhatsAppAlert.jsx';

const VendasPage = () => {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  
  // Estados
  const [products, setProducts] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [sales, setSales] = useState([]);
  const [loading, setLoading] = useState(true);

  // Estados da Venda
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [cartItems, setCartItems] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [discountType, setDiscountType] = useState('fixed');
  const [paymentMethod, setPaymentMethod] = useState('Dinheiro');
  
  const [showReceipt, setShowReceipt] = useState(false);
  const [lastSale, setLastSale] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [creditData, setCreditData] = useState(null);

  const loadData = useCallback(async () => {
    try {
      // Buscamos apenas o que o usuário tem permissão (Produtos, Clientes e Vendas)
      const [productsData, customersData, salesData] = await Promise.all([
        pb.collection('products').getFullList({ sort: 'name', requestKey: null }),
        pb.collection('customers').getFullList({ sort: 'name', requestKey: null }),
        pb.collection('sales').getList(1, 10, {
          sort: '-created',
          expand: 'customerId',
          requestKey: null,
        }),
      ]);
      setProducts(productsData);
      setCustomers(customersData);
      setSales(salesData.items);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // Cálculos de Totais
  const subtotal = useMemo(() => cartItems.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0), [cartItems]);
  const total = useMemo(() => {
    const disc = parseFloat(discountAmount) || 0;
    const res = discountType === 'percentage' ? subtotal - (subtotal * (disc / 100)) : subtotal - disc;
    return Math.max(0, res);
  }, [subtotal, discountAmount, discountType]);

  const addToCart = () => {
    if (!selectedProduct) return;
    const product = products.find(p => p.id === selectedProduct);
    if (!product) return;

    const qty = parseInt(quantity) || 0;
    if (qty <= 0) return;

    const inCart = cartItems.find(i => i.productId === product.id);
    const newQty = (inCart ? inCart.quantity : 0) + qty;

    if (newQty > (product.stockQuantity || 0)) {
      toast({ title: "Estoque insuficiente", variant: "destructive" });
      return;
    }

    if (inCart) {
      setCartItems(cartItems.map(i => i.productId === product.id ? { ...i, quantity: newQty } : i));
    } else {
      setCartItems([...cartItems, { 
        productId: product.id, 
        name: product.name, 
        unitPrice: product.salePrice, 
        quantity: qty 
      }]);
    }
    setSelectedProduct('');
    setQuantity(1);
  };

  const finalizeSale = async () => {
    if (cartItems.length === 0) {
      toast({ title: "Carrinho vazio", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    try {
      // 1. Criar a Venda
      const sale = await pb.collection('sales').create({
        customerId: selectedCustomer || null,
        saleDate: new Date().toISOString(),
        totalAmount: total,
        paymentMethod,
        status: 'completed',
        userId: currentUser.id,
      }, { requestKey: null });

      // 2. Processar Itens e Atualizar Estoque (Garantia ANTI-ERRO)
      for (const item of cartItems) {
        // Buscamos o produto atualizado direto do banco
        const prod = await pb.collection('products').getOne(item.productId, { requestKey: null });
        
        // Calculamos a nova quantidade garantindo que seja um NÚMERO
        const stockAtual = parseInt(prod.stockQuantity) || 0;
        const vendida = parseInt(item.quantity) || 0;
        const novaQtd = Math.max(0, stockAtual - vendida);

        // Criar registro do item vendido
        await pb.collection('saleItems').create({
          saleId: sale.id,
          productId: item.productId,
          quantity: vendida,
          unitPrice: item.unitPrice,
          subtotal: item.unitPrice * vendida
        }, { requestKey: null });

        // ATUALIZAÇÃO DO ESTOQUE: Enviamos explicitamente como número
        await pb.collection('products').update(item.productId, {
          stockQuantity: novaQtd 
        }, { requestKey: null });
      }

      if (paymentMethod === 'Crediário' && creditData) {
        await createCredit({ vendaId: sale.id, clienteId: selectedCustomer, ...creditData });
      }

      setLastSale({ ...sale, items: cartItems, creditData });
      setShowReceipt(true);
      
      // Resetar Form
      setCartItems([]);
      setSelectedCustomer('');
      setDiscountAmount(0);
      
      await loadData();
      toast({ title: "Venda concluída com sucesso!" });
    } catch (e) {
      console.error("Erro na finalização:", e);
      toast({ 
        title: "Erro na venda", 
        description: "Falha ao atualizar o estoque no banco de dados.", 
        variant: "destructive" 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return <div className="p-10 text-center text-slate-500">Carregando Dagostim PDV...</div>;

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <Helmet><title>PDV | Vendas</title></Helmet>
      
      <div className="bg-white border-b p-4 mb-6 shadow-sm flex justify-between items-center">
        <h1 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <ShoppingCart className="text-blue-600" /> Dagostim PDV
        </h1>
        <div className="text-sm text-slate-500">Operador: <strong>{currentUser?.name}</strong></div>
      </div>

      <main className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LADO ESQUERDO: CLIENTE E PRODUTOS */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* SEÇÃO CLIENTE */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h2 className="text-xs font-bold text-slate-400 uppercase mb-3 flex items-center gap-2">
              <User size={14} /> Cliente da Venda
            </h2>
            <select 
              className="w-full p-3 border rounded-lg bg-slate-50 focus:ring-2 focus:ring-blue-500 outline-none"
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
            >
              <option value="">Consumidor Final</option>
              {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          {/* SEÇÃO PRODUTOS */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h2 className="text-xs font-bold text-slate-400 uppercase mb-3 flex items-center gap-2">
              <Package size={14} /> Lançar Itens
            </h2>
            <div className="flex gap-3">
              <select 
                className="flex-1 p-3 border rounded-lg bg-white"
                value={selectedProduct}
                onChange={(e) => setSelectedProduct(e.target.value)}
              >
                <option value="">Pesquisar produto...</option>
                {products.map(p => (
                  <option key={p.id} value={p.id} disabled={p.stockQuantity <= 0}>
                    {p.name} - R$ {p.salePrice?.toFixed(2)} ({p.stockQuantity} un)
                  </option>
                ))}
              </select>
              <input 
                type="number" 
                className="w-24 p-3 border rounded-lg text-center font-bold"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                min="1"
              />
              <Button onClick={addToCart} className="bg-blue-600 hover:bg-blue-700 h-auto px-6">
                <Plus />
              </Button>
            </div>

            {/* LISTA DO CARRINHO */}
            <div className="mt-6 border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-slate-400 uppercase text-[10px] font-black">
                  <tr>
                    <th className="p-4 text-left">Item</th>
                    <th className="p-4 text-center">Qtd</th>
                    <th className="p-4 text-right">Preço</th>
                    <th className="p-4 text-right">Subtotal</th>
                    <th className="p-4 w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {cartItems.map(item => (
                    <tr key={item.productId} className="hover:bg-slate-50">
                      <td className="p-4 font-medium text-slate-700">{item.name}</td>
                      <td className="p-4 text-center font-bold">{item.quantity}</td>
                      <td className="p-4 text-right">R$ {item.unitPrice.toFixed(2)}</td>
                      <td className="p-4 text-right font-black">R$ {(item.unitPrice * item.quantity).toFixed(2)}</td>
                      <td className="p-4 text-center">
                        <button onClick={() => setCartItems(cartItems.filter(i => i.productId !== item.productId))} className="text-slate-300 hover:text-red-500 transition-colors">
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {cartItems.length === 0 && (
                    <tr><td colSpan="5" className="p-12 text-center text-slate-400 italic">O carrinho está vazio</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* LADO DIREITO: RESUMO E PAGAMENTO */}
        <div className="lg:col-span-4">
          <div className="bg-white p-6 rounded-xl shadow-lg border-2 border-blue-50 sticky top-4">
            <h2 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
              <CreditCard className="text-blue-600" /> Checkout
            </h2>

            <div className="space-y-6">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase">Forma de Pagamento</label>
                <select 
                  className="w-full mt-1 p-3 border rounded-lg font-bold text-blue-700 bg-blue-50 outline-none"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                >
                  <option value="Dinheiro">Dinheiro</option>
                  <option value="PIX">PIX</option>
                  <option value="Cartão">Cartão</option>
                  <option value="Crediário">Crediário</option>
                </select>
              </div>

              {paymentMethod === 'Crediário' && (
                <div className="p-4 bg-orange-50 border border-orange-100 rounded-lg">
                  <CreditPaymentForm totalAmount={total} onValidData={setCreditData} />
                </div>
              )}

              <div className="pt-4 border-t border-slate-100 space-y-2">
                <div className="flex justify-between text-slate-500 text-sm">
                  <span>Subtotal</span>
                  <span>R$ {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 text-sm">Desconto</span>
                  <div className="flex gap-2">
                    <input type="number" className="w-16 p-1 border rounded text-right text-sm" value={discountAmount} onChange={(e) => setDiscountAmount(e.target.value)} />
                    <select className="text-xs border rounded bg-white p-1" value={discountType} onChange={(e) => setDiscountType(e.target.value)}>
                      <option value="fixed">R$</option>
                      <option value="percentage">%</option>
                    </select>
                  </div>
                </div>
                <div className="flex justify-between items-end pt-4">
                  <span className="font-bold text-slate-700">TOTAL</span>
                  <span className="text-3xl font-black text-green-600">R$ {total.toFixed(2)}</span>
                </div>
              </div>

              <Button 
                onClick={finalizeSale} 
                disabled={isSubmitting || cartItems.length === 0}
                className="w-full py-8 text-xl font-black bg-green-600 hover:bg-green-700 transition-all shadow-lg active:scale-95"
              >
                {isSubmitting ? "SALVANDO..." : "FINALIZAR VENDA"}
              </Button>
            </div>
          </div>
        </div>
      </main>

      {/* MODAL RECIBO */}
      {showReceipt && lastSale && (
        <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white p-8 rounded-2xl shadow-2xl max-w-sm w-full text-center">
            <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingCart size={32} />
            </div>
            <h3 className="text-xl font-black text-slate-800 uppercase">Venda Sucesso!</h3>
            <p className="text-slate-400 text-sm mb-6">O estoque foi atualizado.</p>
            
            <div className="border-y border-dashed py-4 my-4 text-left text-sm text-slate-600 space-y-1">
              {lastSale.items.map((it, idx) => (
                <div key={idx} className="flex justify-between">
                  <span>{it.quantity}x {it.name}</span>
                  <span>R$ {(it.unitPrice * it.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="pt-2 flex justify-between font-black text-slate-900 text-base">
                <span>TOTAL</span>
                <span>R$ {lastSale.totalAmount.toFixed(2)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" onClick={() => setShowReceipt(false)}>FECHAR</Button>
              <Button className="bg-slate-900" onClick={() => window.print()}><Printer size={16} className="mr-2"/> RECIBO</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VendasPage;