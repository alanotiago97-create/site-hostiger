
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { useToast } from '@/components/ui/use-toast';

import FinancialDashboard from '@/components/financeiro/FinancialDashboard.jsx';
import FinancialFilters from '@/components/financeiro/FinancialFilters.jsx';
import CashFlowSection from '@/components/financeiro/CashFlowSection.jsx';
import FinancialChart from '@/components/financeiro/FinancialChart.jsx';
import ExpensesByCategory from '@/components/financeiro/ExpensesByCategory.jsx';

const FinanceiroPage = () => {
  const { toast } = useToast();
  const { isAdmin, currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  
  const [filters, setFilters] = useState({
    period: 'month',
    search: '',
    paymentMethod: 'all'
  });

  const [stats, setStats] = useState({
    totalSales: 0, totalExpenses: 0, profit: 0, cashBalance: 0
  });
  
  const [transactions, setTransactions] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [expensesList, setExpensesList] = useState([]);

  useEffect(() => {
    loadData();
  }, [filters.period]);

  const loadData = async () => {
    try {
      setLoading(true);
      const today = new Date();
      let startDateStr = '';

      if (filters.period === 'today') {
        startDateStr = today.toISOString().split('T')[0];
      } else if (filters.period === 'week') {
        const weekAgo = new Date(today);
        weekAgo.setDate(weekAgo.getDate() - 7);
        startDateStr = weekAgo.toISOString().split('T')[0];
      } else if (filters.period === 'month') {
        startDateStr = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
      } else if (filters.period === 'year') {
        startDateStr = new Date(today.getFullYear(), 0, 1).toISOString().split('T')[0];
      }

      let dateFilterSales = startDateStr ? `saleDate >= "${startDateStr}" && status = "completed"` : `status = "completed"`;
      let dateFilterExpenses = startDateStr ? `expenseDate >= "${startDateStr}"` : '';
      let dateFilterCaixa = startDateStr ? `data >= "${startDateStr}"` : '';

      const [sales, expenses, caixa] = await Promise.all([
        pb.collection('sales').getFullList({ filter: dateFilterSales, $autoCancel: false }),
        pb.collection('expenses').getFullList({ filter: dateFilterExpenses, sort: '-expenseDate', $autoCancel: false }),
        pb.collection('caixa').getFullList({ filter: dateFilterCaixa, sort: '-data', $autoCancel: false })
      ]);

      // Calculate Stats
      const totalSales = sales.reduce((sum, s) => sum + s.totalAmount, 0);
      const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
      const totalCaixa = caixa.reduce((sum, c) => sum + c.valor, 0);
      
      setStats({
        totalSales,
        totalExpenses,
        profit: totalSales - totalExpenses,
        cashBalance: totalCaixa - totalExpenses // Simplified cash balance logic
      });

      setExpensesList(expenses);

      // Prepare Unified Transactions
      const unified = [
        ...caixa.map(c => ({
          id: c.id,
          source: 'caixa',
          date: c.data,
          description: c.descricao || 'Entrada de Caixa',
          category: 'Caixa',
          type: 'Entrada',
          amount: c.valor,
          paymentMethod: 'Dinheiro' // Default for caixa
        })),
        ...expenses.map(e => ({
          id: e.id,
          source: 'expenses',
          date: e.expenseDate,
          description: e.description || 'Despesa',
          category: e.category,
          type: 'Saída',
          amount: e.amount,
          paymentMethod: 'Dinheiro' // Default for expenses
        }))
      ].sort((a, b) => new Date(b.date) - new Date(a.date));

      setTransactions(unified);

      // Prepare Chart Data (Group by Date)
      const chartMap = {};
      sales.forEach(s => {
        const d = s.saleDate.split(' ')[0];
        if (!chartMap[d]) chartMap[d] = { date: d, receitas: 0, despesas: 0 };
        chartMap[d].receitas += s.totalAmount;
      });
      expenses.forEach(e => {
        const d = e.expenseDate.split(' ')[0];
        if (!chartMap[d]) chartMap[d] = { date: d, receitas: 0, despesas: 0 };
        chartMap[d].despesas += e.amount;
      });

      const sortedChartData = Object.values(chartMap).sort((a, b) => new Date(a.date) - new Date(b.date));
      setChartData(sortedChartData);

    } catch (error) {
      console.error('Error loading financial data:', error);
      toast({ title: 'Erro', description: 'Falha ao carregar dados financeiros', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteTransaction = async (id, source) => {
    if (!isAdmin) return;
    if (!window.confirm('Deseja realmente excluir este registro?')) return;

    try {
      await pb.collection(source).delete(id, { $autoCancel: false });
      toast({ title: 'Sucesso', description: 'Registro excluído com sucesso' });
      loadData();
    } catch (error) {
      console.error('Error deleting transaction:', error);
      toast({ title: 'Erro', description: 'Falha ao excluir registro', variant: 'destructive' });
    }
  };

  // Apply local filters (search, payment method)
  const filteredTransactions = transactions.filter(t => {
    const matchesSearch = t.description.toLowerCase().includes(filters.search.toLowerCase()) || 
                          t.category.toLowerCase().includes(filters.search.toLowerCase());
    const matchesPayment = filters.paymentMethod === 'all' || t.paymentMethod === filters.paymentMethod;
    return matchesSearch && matchesPayment;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f5f7fa] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Financeiro - Dashboard</title>
        <meta name="description" content="Dashboard financeiro completo" />
      </Helmet>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#1a3a3a]">Dashboard Financeiro</h1>
          <p className="text-gray-500 mt-1">Visão geral de receitas, despesas e fluxo de caixa</p>
        </div>

        <FinancialDashboard stats={stats} />
        
        <FinancialFilters filters={filters} onFilterChange={setFilters} />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
          <div className="xl:col-span-2">
            <FinancialChart data={chartData} />
          </div>
          <div className="xl:col-span-1">
            <ExpensesByCategory expenses={expensesList} />
          </div>
        </div>

        <CashFlowSection 
          transactions={filteredTransactions} 
          onDelete={handleDeleteTransaction}
          isAdmin={isAdmin}
        />
      </main>
    </>
  );
};

export default FinanceiroPage;
