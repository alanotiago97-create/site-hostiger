import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import pb from '@/lib/pocketbaseClient';
import { TrendingUp, DollarSign, AlertTriangle, ShoppingCart, ArrowUpRight, Package, Wallet } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
const Dashboard = () => {
  const {
    toast
  } = useToast();
  const [stats, setStats] = useState({
    todaySales: 0,
    monthSales: 0,
    cashBalance: 0
  });
  const [lowStockProducts, setLowStockProducts] = useState([]);
  const [recentSales, setRecentSales] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    loadDashboardData();
  }, []);
  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const today = new Date().toISOString().split('T')[0];
      const firstDayOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
      const [todaySalesData, monthSalesData, caixaEntries, allExpenses, products, sales] = await Promise.all([pb.collection('sales').getFullList({
        filter: `saleDate >= "${today}" && status = "completed"`,
        $autoCancel: false
      }), pb.collection('sales').getFullList({
        filter: `saleDate >= "${firstDayOfMonth}" && status = "completed"`,
        $autoCancel: false
      }), pb.collection('caixa').getFullList({
        $autoCancel: false
      }), pb.collection('expenses').getFullList({
        $autoCancel: false
      }), pb.collection('products').getFullList({
        filter: 'stockQuantity < 10',
        sort: 'stockQuantity',
        $autoCancel: false
      }), pb.collection('sales').getList(1, 5, {
        sort: '-created',
        expand: 'customerId',
        $autoCancel: false
      })]);
      const todayTotal = todaySalesData.reduce((sum, sale) => sum + (sale.totalAmount || 0), 0);
      const monthTotal = monthSalesData.reduce((sum, sale) => sum + (sale.totalAmount || 0), 0);
      const totalCaixa = caixaEntries.reduce((sum, item) => sum + (item.valor || 0), 0);
      const totalExpenses = allExpenses.reduce((sum, item) => sum + (item.amount || 0), 0);
      setStats({
        todaySales: todayTotal,
        monthSales: monthTotal,
        cashBalance: totalCaixa - totalExpenses
      });
      setLowStockProducts(products);
      setRecentSales(sales.items);
    } catch (error) {
      console.error('Error loading dashboard:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao carregar dados do dashboard.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };
  const formatCurrency = value => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  const formatDate = dateString => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };
  const SkeletonCard = () => <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 animate-pulse">
      <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
      <div className="h-8 bg-gray-200 rounded w-3/4 mb-2"></div>
      <div className="h-4 bg-gray-200 rounded w-1/3"></div>
    </div>;
  return <>
      <Helmet>
        <title>Dashboard - Dagostim Importados</title>
        <meta name="description" content="Painel de controle e estatísticas de vendas" />
      </Helmet>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#1a3a3a]">Dashboard</h1>
          <p className="text-[#7f8c8d] mt-1">Visão geral do seu negócio hoje</p>
        </div>

        {loading ? <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </div> : <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#4a7ba7]/5 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-110"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <p className="text-[#7f8c8d] text-sm font-medium uppercase tracking-wider">Vendas Hoje</p>
                  <p className="text-4xl font-bold text-[#1a3a3a] mt-2">{formatCurrency(stats.todaySales)}</p>
                  <div className="flex items-center mt-2 text-[#2ecc71] text-sm font-medium">
                    <ArrowUpRight className="h-4 w-4 mr-1" />
                    <span>Atualizado agora</span>
                  </div>
                </div>
                <div className="h-14 w-14 bg-[#4a7ba7]/10 rounded-full flex items-center justify-center text-[#4a7ba7]">
                  <DollarSign className="h-8 w-8" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#2ecc71]/5 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-110"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <p className="text-[#7f8c8d] text-sm font-medium uppercase tracking-wider">Vendas Este Mês</p>
                  <p className="text-4xl font-bold text-[#1a3a3a] mt-2">{formatCurrency(stats.monthSales)}</p>
                  <div className="flex items-center mt-2 text-[#4a7ba7] text-sm font-medium">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    <span>Acumulado mensal</span>
                  </div>
                </div>
                <div className="h-14 w-14 bg-[#2ecc71]/10 rounded-full flex items-center justify-center text-[#2ecc71]">
                  <TrendingUp className="h-8 w-8" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#f39c12]/5 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-110"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <p className="text-[#7f8c8d] text-sm font-medium uppercase tracking-wider">Saldo em Caixa</p>
                  <p className={`text-4xl font-bold mt-2 ${stats.cashBalance >= 0 ? 'text-[#1a3a3a]' : 'text-red-500'}`}>
                    {formatCurrency(stats.cashBalance)}
                  </p>
                  <div className="flex items-center mt-2 text-[#f39c12] text-sm font-medium">
                    <Wallet className="h-4 w-4 mr-1" />
                    <span>Caixa - Despesas</span>
                  </div>
                </div>
                <div className="h-14 w-14 bg-[#f39c12]/10 rounded-full flex items-center justify-center text-[#f39c12]">
                  <Wallet className="h-8 w-8" />
                </div>
              </div>
            </div>
          </div>}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Low Stock Products */}
          <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
            <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex items-center justify-between">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-[#f39c12] mr-2" />
                <h2 className="text-lg font-bold text-[#1a3a3a]">Estoque Baixo</h2>
              </div>
              <span className="bg-[#f39c12]/10 text-[#f39c12] text-xs font-bold px-2 py-1 rounded-full">
                {lowStockProducts.length} itens
              </span>
            </div>
            <div className="p-6">
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                {loading ? <div className="animate-pulse space-y-4">
                    {[1, 2, 3].map(i => <div key={i} className="h-12 bg-gray-100 rounded"></div>)}
                  </div> : lowStockProducts.length === 0 ? <div className="text-center py-8 text-[#7f8c8d]">
                    <Package className="h-12 w-12 mx-auto mb-2 opacity-20" />
                    <p>Estoque saudável!</p>
                  </div> : lowStockProducts.map(product => <div key={product.id} className="p-4 rounded-lg border border-gray-100 hover:border-[#f39c12]/30 hover:bg-[#f39c12]/5 transition-colors flex justify-between items-center group">
                      <div>
                        <p className="text-[#2c3e50] font-semibold group-hover:text-[#1a3a3a]">{product.name}</p>
                        <p className="text-[#7f8c8d] text-xs">{product.brand || 'Sem marca'}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold text-lg ${product.stockQuantity === 0 ? 'text-red-500' : 'text-[#f39c12]'}`}>
                          {product.stockQuantity} un.
                        </p>
                        <p className="text-xs text-[#7f8c8d]">Restantes</p>
                      </div>
                    </div>)}
              </div>
            </div>
          </div>

          {/* Recent Sales */}
          <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
            <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex items-center justify-between">
              <div className="flex items-center">
                <ShoppingCart className="h-5 w-5 text-[#4a7ba7] mr-2" />
                <h2 className="text-lg font-bold text-[#1a3a3a]">Últimas Vendas</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-3">
                {loading ? <div className="animate-pulse space-y-4">
                    {[1, 2, 3].map(i => <div key={i} className="h-16 bg-gray-100 rounded"></div>)}
                  </div> : recentSales.length === 0 ? <div className="text-center py-8 text-[#7f8c8d]">
                    <ShoppingCart className="h-12 w-12 mx-auto mb-2 opacity-20" />
                    <p>Nenhuma venda registrada recentemente</p>
                  </div> : recentSales.map(sale => <div key={sale.id} className="p-4 bg-gray-50 rounded-lg border border-gray-100 hover:bg-white hover:shadow-md transition-all">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-[#4a7ba7]/10 flex items-center justify-center text-[#4a7ba7] font-bold">
                            {sale.expand?.customerId?.name ? sale.expand.customerId.name.charAt(0) : '?'}
                          </div>
                          <div>
                            <p className="text-[#2c3e50] font-medium">
                              {sale.expand?.customerId?.name || 'Cliente não informado'}
                            </p>
                            <p className="text-[#7f8c8d] text-xs flex items-center gap-2">
                              <span>{formatDate(sale.saleDate)}</span>
                              <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                              <span>{sale.paymentMethod}</span>
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-[#2ecc71] font-bold text-lg">{formatCurrency(sale.totalAmount)}</p>
                          <span className="text-[10px] uppercase tracking-wider font-bold text-[#7f8c8d] bg-gray-200 px-2 py-0.5 rounded-full">
                            {sale.status === 'completed' ? 'Concluído' : 'Cancelado'}
                          </span>
                        </div>
                      </div>
                    </div>)}
              </div>
            </div>
          </div>
        </div>
      </main>
    </>;
};
export default Dashboard;