
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import pb from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Edit, Trash2, Search, ShoppingBag, X, User, Phone, Mail, Calendar } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ClientesPage = () => {
  const { toast } = useToast();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [viewingHistory, setViewingHistory] = useState(null);
  const [customerSales, setCustomerSales] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    birthday: '',
    notes: '',
  });

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    try {
      const data = await pb.collection('customers').getFullList({
        sort: 'name',
        $autoCancel: false,
      });
      setCustomers(data);
    } catch (error) {
      console.error('Error loading customers:', error);
      toast({ title: 'Erro', description: 'Falha ao carregar clientes', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const data = {
        name: formData.name,
        phone: formData.phone || null,
        email: formData.email || null,
        birthday: formData.birthday || null,
        notes: formData.notes || null,
      };

      if (editingCustomer) {
        await pb.collection('customers').update(editingCustomer.id, data, { $autoCancel: false });
        toast({ title: 'Sucesso', description: 'Cliente atualizado com sucesso' });
      } else {
        await pb.collection('customers').create(data, { $autoCancel: false });
        toast({ title: 'Sucesso', description: 'Cliente cadastrado com sucesso' });
      }

      resetForm();
      loadCustomers();
    } catch (error) {
      console.error('Error saving customer:', error);
      toast({ title: 'Erro', description: 'Falha ao salvar cliente', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', phone: '', email: '', birthday: '', notes: '' });
    setEditingCustomer(null);
  };

  const handleEdit = (customer) => {
    setFormData({
      name: customer.name,
      phone: customer.phone || '',
      email: customer.email || '',
      birthday: customer.birthday || '',
      notes: customer.notes || '',
    });
    setEditingCustomer(customer);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Deseja realmente excluir este cliente?')) return;

    try {
      await pb.collection('customers').delete(id, { $autoCancel: false });
      toast({ title: 'Sucesso', description: 'Cliente excluído com sucesso' });
      loadCustomers();
    } catch (error) {
      console.error('Error deleting customer:', error);
      toast({ title: 'Erro', description: 'Falha ao excluir cliente', variant: 'destructive' });
    }
  };

  const viewPurchaseHistory = async (customer) => {
    try {
      const sales = await pb.collection('sales').getFullList({
        filter: `customerId = "${customer.id}"`,
        sort: '-saleDate',
        $autoCancel: false,
      });
      setCustomerSales(sales);
      setViewingHistory(customer);
    } catch (error) {
      console.error('Error loading purchase history:', error);
      toast({ title: 'Erro', description: 'Falha ao carregar histórico', variant: 'destructive' });
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (customer.phone && customer.phone.includes(searchQuery)) ||
    (customer.email && customer.email.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f5f7fa] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4a7ba7]"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Clientes - Dagostim Importados</title>
        <meta name="description" content="Gerenciamento de clientes" />
      </Helmet>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#1a3a3a]">Clientes</h1>
          <p className="text-[#7f8c8d] mt-1">Gerencie sua base de clientes</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden sticky top-24">
              <div className="p-6 border-b border-gray-100 bg-gray-50/50">
                <h2 className="text-xl font-bold text-[#1a3a3a] flex items-center gap-2">
                  <User className="h-5 w-5 text-[#4a7ba7]" />
                  {editingCustomer ? 'Editar Cliente' : 'Novo Cliente'}
                </h2>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Nome *</label>
                  <input type="text" name="name" value={formData.name} onChange={handleInputChange} required className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Telefone</label>
                  <input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Email</label>
                  <input type="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Data de Nascimento</label>
                  <input type="date" name="birthday" value={formData.birthday} onChange={handleInputChange} className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2c3e50] mb-2">Observações</label>
                  <textarea name="notes" value={formData.notes} onChange={handleInputChange} rows="3" className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                </div>

                <div className="flex gap-2 pt-2">
                  <Button type="submit" disabled={isSubmitting} className="flex-1 bg-[#4a7ba7] hover:bg-[#3a6b97] text-white shadow-md">
                    {isSubmitting ? 'Salvando...' : (editingCustomer ? 'Atualizar' : 'Cadastrar')}
                  </Button>
                  {editingCustomer && (
                    <Button type="button" onClick={resetForm} variant="outline" className="border-[#4a7ba7] text-[#4a7ba7] hover:bg-[#4a7ba7]/10">
                      Cancelar
                    </Button>
                  )}
                </div>
              </form>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col md:flex-row justify-between items-center gap-4">
                <h2 className="text-xl font-bold text-[#1a3a3a]">Clientes Cadastrados</h2>
                <div className="relative w-full md:w-64">
                  <input type="text" placeholder="Buscar clientes..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" />
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                </div>
              </div>

              <div className="p-6">
                <div className="space-y-4">
                  {filteredCustomers.length === 0 ? (
                    <p className="text-[#7f8c8d] text-center py-8">Nenhum cliente encontrado</p>
                  ) : (
                    filteredCustomers.map((customer) => (
                      <div key={customer.id} className="p-4 bg-white rounded-lg border border-gray-100 hover:shadow-md hover:border-[#4a7ba7]/30 transition-all">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <div className="h-10 w-10 rounded-full bg-[#4a7ba7]/10 flex items-center justify-center text-[#4a7ba7] font-bold">
                                {customer.name.charAt(0).toUpperCase()}
                              </div>
                              <h3 className="text-[#1a3a3a] font-bold text-lg">{customer.name}</h3>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3 text-sm">
                              {customer.phone && (
                                <div className="flex items-center text-[#7f8c8d]">
                                  <Phone className="h-4 w-4 mr-2 text-[#4a7ba7]" />
                                  {customer.phone}
                                </div>
                              )}
                              {customer.email && (
                                <div className="flex items-center text-[#7f8c8d]">
                                  <Mail className="h-4 w-4 mr-2 text-[#4a7ba7]" />
                                  {customer.email}
                                </div>
                              )}
                              {customer.birthday && (
                                <div className="flex items-center text-[#7f8c8d]">
                                  <Calendar className="h-4 w-4 mr-2 text-[#4a7ba7]" />
                                  {formatDate(customer.birthday)}
                                </div>
                              )}
                            </div>
                            
                            {customer.notes && (
                              <div className="mt-3 p-2 bg-gray-50 rounded text-sm text-[#7f8c8d] italic border-l-2 border-[#4a7ba7]">
                                {customer.notes}
                              </div>
                            )}
                          </div>
                          <div className="flex gap-2 ml-4">
                            <button onClick={() => viewPurchaseHistory(customer)} className="text-[#4a7ba7] hover:text-[#3a6b97] p-2 hover:bg-[#4a7ba7]/10 rounded-full transition-colors" title="Ver histórico de compras"><ShoppingBag className="h-5 w-5" /></button>
                            <button onClick={() => handleEdit(customer)} className="text-[#f39c12] hover:text-[#e67e22] p-2 hover:bg-[#f39c12]/10 rounded-full transition-colors"><Edit className="h-5 w-5" /></button>
                            <button onClick={() => handleDelete(customer.id)} className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded-full transition-colors"><Trash2 className="h-5 w-5" /></button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {viewingHistory && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
              <h2 className="text-2xl font-bold text-[#1a3a3a]">
                Histórico de Compras - {viewingHistory.name}
              </h2>
              <button onClick={() => setViewingHistory(null)} className="text-gray-400 hover:text-gray-600 transition-colors">
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-3">
              {customerSales.length === 0 ? (
                <p className="text-[#7f8c8d] text-center py-8">Nenhuma compra registrada</p>
              ) : (
                customerSales.map((sale) => (
                  <div key={sale.id} className={`p-4 rounded-lg border ${sale.status === 'cancelled' ? 'bg-red-50 border-red-100' : 'bg-gray-50 border-gray-100'}`}>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-[#1a3a3a] font-medium">{formatDate(sale.saleDate)}</p>
                        <p className="text-[#7f8c8d] text-sm">{sale.paymentMethod}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold text-lg ${sale.status === 'cancelled' ? 'text-red-500 line-through' : 'text-[#2ecc71]'}`}>
                          {formatCurrency(sale.totalAmount)}
                        </p>
                        {sale.status === 'cancelled' && <p className="text-red-500 text-xs font-bold">CANCELADA</p>}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {customerSales.length > 0 && (
              <div className="mt-6 pt-6 border-t border-gray-100">
                <div className="flex justify-between items-center">
                  <span className="text-[#2c3e50] font-medium">Total Gasto:</span>
                  <span className="text-[#4a7ba7] text-2xl font-bold">
                    {formatCurrency(customerSales.filter(s => s.status === 'completed').reduce((sum, sale) => sum + sale.totalAmount, 0))}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default ClientesPage;
