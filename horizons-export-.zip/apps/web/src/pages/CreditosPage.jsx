
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { getCredits, updateCredit } from '@/services/creditService.js';
import { Button } from '@/components/ui/button';
import { Search, Filter, CheckCircle, Clock, AlertCircle, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import WhatsAppAlert from '@/components/WhatsAppAlert.jsx';

const CreditosPage = () => {
  const { toast } = useToast();
  const [credits, setCredits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [selectedCredit, setSelectedCredit] = useState(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadCredits();
  }, [statusFilter]);

  const loadCredits = async () => {
    try {
      setLoading(true);
      const data = await getCredits(statusFilter);
      setCredits(data);
    } catch (error) {
      console.error('Error loading credits:', error);
      toast({ title: 'Erro', description: 'Falha ao carregar crediários', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handlePayment = async (e) => {
    e.preventDefault();
    if (!selectedCredit || !paymentAmount) return;

    const amount = parseFloat(paymentAmount);
    if (amount <= 0 || amount > selectedCredit.valorRestante) {
      toast({ title: 'Erro', description: 'Valor de pagamento inválido', variant: 'destructive' });
      return;
    }

    setIsSubmitting(true);
    try {
      await updateCredit(selectedCredit.id, {
        valorPago: selectedCredit.valorPago + amount
      });
      
      toast({ title: 'Sucesso', description: 'Pagamento registrado com sucesso' });
      setSelectedCredit(null);
      setPaymentAmount('');
      loadCredits();
    } catch (error) {
      console.error('Error updating credit:', error);
      toast({ title: 'Erro', description: 'Falha ao registrar pagamento', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pago':
        return <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 flex items-center gap-1"><CheckCircle className="w-3 h-3" /> Pago</span>;
      case 'vencido':
        return <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800 flex items-center gap-1"><AlertCircle className="w-3 h-3" /> Vencido</span>;
      case 'em_aberto':
      default:
        return <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 flex items-center gap-1"><Clock className="w-3 h-3" /> Em Aberto</span>;
    }
  };

  const filteredCredits = credits.filter(credit => {
    const customerName = credit.expand?.clienteId?.name || '';
    return customerName.toLowerCase().includes(searchQuery.toLowerCase());
  });

  if (loading && credits.length === 0) {
    return (
      <div className="min-h-screen bg-[#f5f7fa] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4a7ba7]"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Crediários - Dagostim Importados</title>
        <meta name="description" content="Gerenciamento de crediários e cobranças" />
      </Helmet>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#1a3a3a]">Crediários</h1>
          <p className="text-[#7f8c8d] mt-1">Controle de parcelamentos e cobranças</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="relative w-full md:w-96">
              <input 
                type="text" 
                placeholder="Buscar por cliente..." 
                value={searchQuery} 
                onChange={(e) => setSearchQuery(e.target.value)} 
                className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-[#2c3e50] focus:outline-none focus:border-[#4a7ba7] focus:ring-1 focus:ring-[#4a7ba7]" 
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            </div>
            
            <div className="flex items-center gap-2 w-full md:w-auto">
              <Filter className="h-4 w-4 text-gray-400" />
              <select 
                value={statusFilter} 
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full md:w-auto px-4 py-2 bg-white border border-gray-200 rounded-lg text-[#2c3e50] focus:outline-none focus:border-[#4a7ba7] focus:ring-1 focus:ring-[#4a7ba7]"
              >
                <option value="">Todos os Status</option>
                <option value="em_aberto">Em Aberto</option>
                <option value="vencido">Vencidos</option>
                <option value="pago">Pagos</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Cliente</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Vencimento</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Valor Total</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Restante</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredCredits.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-8 text-center text-gray-500">Nenhum crediário encontrado</td>
                  </tr>
                ) : (
                  filteredCredits.map((credit) => (
                    <tr key={credit.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-bold text-[#2c3e50]">{credit.expand?.clienteId?.name || 'Cliente Desconhecido'}</div>
                        <div className="text-xs text-gray-500">{credit.telefoneCliente}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {formatDate(credit.dataVencimento)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900">
                        {formatCurrency(credit.valorTotal)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-bold text-red-600">
                        {formatCurrency(credit.valorRestante)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        {getStatusBadge(credit.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end items-center gap-2">
                          {credit.status !== 'pago' && (
                            <>
                              <WhatsAppAlert 
                                phone={credit.telefoneCliente}
                                clientName={credit.expand?.clienteId?.name || 'Cliente'}
                                amount={credit.valorRestante}
                                dueDate={credit.dataVencimento}
                              />
                              <Button 
                                onClick={() => setSelectedCredit(credit)}
                                size="sm"
                                className="bg-[#4a7ba7] hover:bg-[#3a6b97] text-white h-8"
                              >
                                Receber
                              </Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Payment Modal */}
      {selectedCredit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
              <h3 className="text-lg font-bold text-[#1a3a3a]">Registrar Pagamento</h3>
              <button onClick={() => setSelectedCredit(null)} className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-full hover:bg-gray-200"><X className="h-6 w-6" /></button>
            </div>
            
            <form onSubmit={handlePayment} className="p-6 space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-4">
                <p className="text-sm text-blue-800 mb-1">Cliente: <span className="font-bold">{selectedCredit.expand?.clienteId?.name}</span></p>
                <p className="text-sm text-blue-800 mb-1">Valor Restante: <span className="font-bold text-red-600">{formatCurrency(selectedCredit.valorRestante)}</span></p>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-[#2c3e50]">Valor a Receber *</label>
                <input 
                  type="number" 
                  step="0.01" 
                  min="0.01" 
                  max={selectedCredit.valorRestante}
                  value={paymentAmount} 
                  onChange={(e) => setPaymentAmount(e.target.value)} 
                  required 
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#4a7ba7]" 
                  placeholder="0.00" 
                />
              </div>
              
              <div className="flex justify-end gap-3 mt-6 pt-2">
                <Button type="button" variant="outline" onClick={() => setSelectedCredit(null)}>Cancelar</Button>
                <Button type="submit" disabled={isSubmitting || !paymentAmount} className="bg-[#2ecc71] hover:bg-[#27ae60] text-white">
                  {isSubmitting ? 'Processando...' : 'Confirmar Pagamento'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default CreditosPage;
