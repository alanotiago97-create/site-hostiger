
import React, { createContext, useContext, useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [initialLoading, setInitialLoading] = useState(true);

  useEffect(() => {
    if (pb.authStore.isValid && pb.authStore.model) {
      setCurrentUser(pb.authStore.model);
    }
    setInitialLoading(false);

    const unsubscribe = pb.authStore.onChange((token, model) => {
      setCurrentUser(model);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const login = async (email, password) => {
    try {
      const authData = await pb.collection('users').authWithPassword(email, password);
      setCurrentUser(authData.record);
      return { success: true, user: authData.record };
    } catch (error) {
      console.error('Login error:', error);
      throw new Error('Falha no login. Verifique seu email e senha.');
    }
  };

  const signup = async (email, password, passwordConfirm, name, role = 'vendedor') => {
    try {
      const record = await pb.collection('users').create({
        email,
        password,
        passwordConfirm,
        name,
        role,
      });
      // Auto login after signup
      await login(email, password);
      return { success: true, user: record };
    } catch (error) {
      console.error('Signup error:', error);
      throw new Error(error.message || 'Falha no cadastro. Verifique os dados informados.');
    }
  };

  const logout = () => {
    pb.authStore.clear();
    setCurrentUser(null);
  };

  const isAuthenticated = pb.authStore.isValid && currentUser !== null;
  const isAdmin = currentUser?.role === 'admin';
  const isVendedor = currentUser?.role === 'vendedor';

  const value = {
    currentUser,
    login,
    signup,
    logout,
    isAuthenticated,
    isAdmin,
    isVendedor,
    initialLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
