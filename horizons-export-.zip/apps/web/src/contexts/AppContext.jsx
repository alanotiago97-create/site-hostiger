
import React, { createContext, useContext, useState, useEffect } from 'react';
import { getSettings } from '@/services/uploadService.js';

const AppContext = createContext(null);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};

export const AppProvider = ({ children }) => {
  const [settings, setSettings] = useState({
    logoPath: null,
    companyName: 'Dagostim Importados',
  });
  const [loading, setLoading] = useState(true);

  const loadSettings = async () => {
    try {
      const data = await getSettings();
      setSettings({
        logoPath: data.logoPath || null,
        companyName: data.companyName || 'Dagostim Importados',
      });
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  return (
    <AppContext.Provider value={{ settings, setSettings, refreshSettings: loadSettings, loading }}>
      {children}
    </AppContext.Provider>
  );
};
