
import React from 'react';
import { generateWhatsAppLink, generateMessage } from '@/services/whatsappService.js';
import { MessageCircle } from 'lucide-react';

const WhatsAppAlert = ({ phone, clientName, amount, dueDate, className = '' }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const handleSendAlert = () => {
    if (!phone) return;
    const message = generateMessage(clientName, formatCurrency(amount), formatDate(dueDate));
    const link = generateWhatsAppLink(phone, message);
    window.open(link, '_blank');
  };

  return (
    <button
      onClick={handleSendAlert}
      disabled={!phone}
      className={`inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#128C7E] text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
      title="Enviar cobrança via WhatsApp"
    >
      <MessageCircle className="w-4 h-4" />
      <span>Cobrar</span>
    </button>
  );
};

export default WhatsAppAlert;
