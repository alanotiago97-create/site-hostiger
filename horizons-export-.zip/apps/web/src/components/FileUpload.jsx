
import React, { useState, useRef } from 'react';
import { UploadCloud, X, Image as ImageIcon } from 'lucide-react';

const FileUpload = ({ onFileSelect, accept, maxSizeMB, previewUrl, onClear }) => {
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef(null);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const validateFile = (file) => {
    setError('');
    if (!file) return false;

    const validTypes = accept.split(',').map(type => type.trim());
    const fileType = file.type;
    const fileExtension = `.${file.name.split('.').pop().toLowerCase()}`;

    const isValidType = validTypes.some(type => 
      type === fileType || type === fileExtension || (type.includes('/*') && fileType.startsWith(type.split('/')[0]))
    );

    if (!isValidType) {
      setError(`Formato inválido. Aceito: ${accept}`);
      return false;
    }

    if (file.size > maxSizeMB * 1024 * 1024) {
      setError(`Arquivo muito grande. Máximo: ${maxSizeMB}MB`);
      return false;
    }

    return true;
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (validateFile(file)) {
        onFileSelect(file);
      }
    }
  };

  const handleChange = (e) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (validateFile(file)) {
        onFileSelect(file);
      }
    }
  };

  return (
    <div className="w-full">
      {previewUrl ? (
        <div className="relative rounded-lg overflow-hidden border border-gray-200 bg-gray-50 flex items-center justify-center h-48">
          <img src={previewUrl} alt="Preview" className="max-h-full max-w-full object-contain" />
          <button
            type="button"
            onClick={onClear}
            className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors shadow-md"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ) : (
        <div
          className={`relative border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center h-48 transition-colors cursor-pointer
            ${dragActive ? 'border-[#4a7ba7] bg-[#4a7ba7]/5' : 'border-gray-300 bg-gray-50 hover:bg-gray-100'}
            ${error ? 'border-red-400 bg-red-50' : ''}
          `}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
        >
          <input
            ref={inputRef}
            type="file"
            accept={accept}
            onChange={handleChange}
            className="hidden"
          />
          <UploadCloud className={`h-10 w-10 mb-3 ${error ? 'text-red-400' : 'text-gray-400'}`} />
          <p className="text-sm font-medium text-gray-700 text-center">
            Arraste uma imagem ou clique para selecionar
          </p>
          <p className="text-xs text-gray-500 mt-1 text-center">
            {accept.replace(/image\//g, '').toUpperCase()} até {maxSizeMB}MB
          </p>
          {error && <p className="text-xs text-red-500 mt-2 font-medium">{error}</p>}
        </div>
      )}
    </div>
  );
};

export default FileUpload;
