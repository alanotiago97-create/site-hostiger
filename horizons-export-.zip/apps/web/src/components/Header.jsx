
import React, { useState } from 'react';
import { Search, Bell, Menu } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { useAppContext } from '@/contexts/AppContext.jsx';

const Header = ({ onMenuClick }) => {
  const { currentUser } = useAuth();
  const { settings } = useAppContext();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-30 h-16 px-4 sm:px-8 flex items-center justify-between border-b border-gray-100">
      <div className="flex items-center gap-4 flex-1">
        {/* Mobile Menu Toggle */}
        <button 
          onClick={onMenuClick}
          className="lg:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-lg"
        >
          <Menu className="h-6 w-6" />
        </button>

        {/* Search Bar */}
        <div className="flex-1 max-w-xl hidden sm:block">
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              placeholder="Buscar no sistema..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-50 text-[#2c3e50] border border-gray-200 rounded-full pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-[#4a7ba7] focus:ring-1 focus:ring-[#4a7ba7] transition-all placeholder-gray-400"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400 pointer-events-none" />
          </form>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-3 sm:gap-4 ml-4">
        {settings.logoPath && (
          <div className="hidden md:flex items-center mr-4">
            <img src={settings.logoPath} alt={settings.companyName} className="h-8 object-contain" />
          </div>
        )}
        
        <button 
          className="relative p-2 text-gray-400 hover:text-[#1a3a3a] transition-colors rounded-full hover:bg-gray-100"
          aria-label="Notificações"
        >
          <Bell className="h-5 w-5" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>
        
        <div className="h-8 w-[1px] bg-gray-200 hidden sm:block"></div>
        
        <div className="text-right hidden sm:block">
          <p className="text-xs text-gray-500">Bem-vindo de volta,</p>
          <p className="text-sm font-bold text-[#1a3a3a]">{currentUser?.name || 'Usuário'}</p>
        </div>
      </div>
    </header>
  );
};

export default Header;
