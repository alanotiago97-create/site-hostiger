
import React, { useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Plus, Search, Trash2, Calendar, DollarSign } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import CaixaForm from './CaixaForm';

const CaixaTab = () => {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [totalCaixa, setTotalCaixa] = useState(0);

  useEffect(() => {
    if (currentUser) {
      loadEntries();
    }
  }, [currentUser, searchQuery]);

  const loadEntries = async () => {
    try {
      setLoading(true);
      let filter = `userId = "${currentUser.id}"`;
      
      if (searchQuery) {
        filter += ` && descricao ~ "${searchQuery}"`;
      }

      const result = await pb.collection('caixa').getList(1, 50, {
        filter: filter,
        sort: '-data,-created',
        $autoCancel: false,
      });

      setEntries(result.items);
      
      // Calculate total (fetching all for accurate total, or just sum current page if that's the requirement, 
      // but usually total implies all. For simplicity/performance in this demo, we'll sum the fetched list 
      // or do a separate aggregation if needed. Let's fetch all for total calculation to be accurate)
      const allEntries = await pb.collection('caixa').getFullList({
        filter: `userId = "${currentUser.id}"`,
        $autoCancel: false,
      });
      const total = allEntries.reduce((sum, item) => sum + (item.valor || 0), 0);
      setTotalCaixa(total);

    } catch (error) {
      console.error('Erro ao carregar caixa:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar os dados do caixa.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir esta entrada?')) return;

    try {
      await pb.collection('caixa').delete(id, { $autoCancel: false });
      toast({
        title: 'Sucesso',
        description: 'Entrada excluída com sucesso.',
      });
      loadEntries();
    } catch (error) {
      console.error('Erro ao excluir:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao excluir entrada.',
        variant: 'destructive',
      });
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 w-full md:w-auto">
          <div className="p-3 bg-[#f39c12]/10 rounded-full text-[#f39c12]">
            <DollarSign className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Total em Caixa</p>
            <p className="text-2xl font-bold text-[#1a3a3a]">{formatCurrency(totalCaixa)}</p>
          </div>
        </div>

        <div className="flex gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <input
              type="text"
              placeholder="Buscar por descrição..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-[#2c3e50] focus:outline-none focus:ring-2 focus:ring-[#4a7ba7] focus:border-transparent"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          </div>
          <Button
            onClick={() => setIsFormOpen(true)}
            className="bg-[#f39c12] hover:bg-[#e67e22] text-white shadow-md whitespace-nowrap"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nova Entrada
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-100 bg-gray-50/50">
          <h2 className="text-xl font-bold text-[#1a3a3a]">Entradas de Caixa</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Data</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Descrição</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Valor</th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-[#7f8c8d] uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                <tr>
                  <td colSpan="4" className="px-6 py-8 text-center text-gray-500">
                    Carregando...
                  </td>
                </tr>
              ) : entries.length === 0 ? (
                <tr>
                  <td colSpan="4" className="px-6 py-8 text-center text-gray-500">
                    Nenhuma entrada encontrada.
                  </td>
                </tr>
              ) : (
                entries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-[#2c3e50]">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        {formatDate(entry.data)}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-[#2c3e50]">
                      {entry.descricao || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-[#2ecc71]">
                      {formatCurrency(entry.valor)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleDelete(entry.id)}
                        className="text-red-400 hover:text-red-600 p-2 hover:bg-red-50 rounded-full transition-colors"
                        title="Excluir"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <CaixaForm 
        isOpen={isFormOpen} 
        onClose={() => setIsFormOpen(false)} 
        onSuccess={loadEntries} 
      />
    </div>
  );
};

export default CaixaTab;
