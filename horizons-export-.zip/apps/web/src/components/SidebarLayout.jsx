
import React, { useState } from 'react';
import Sidebar from '@/components/Sidebar.jsx';
import Header from '@/components/Header.jsx';

const SidebarLayout = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-[#f5f7fa]">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col lg:ml-[240px] min-w-0 transition-all duration-300">
        <Header onMenuClick={() => setIsSidebarOpen(true)} />
        
        <div className="flex-1 w-full">
          {children}
        </div>
      </div>
    </div>
  );
};

export default SidebarLayout;
