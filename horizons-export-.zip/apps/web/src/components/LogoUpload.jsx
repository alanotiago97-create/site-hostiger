
import React, { useState } from 'react';
import FileUpload from '@/components/FileUpload.jsx';
import { Button } from '@/components/ui/button';
import { uploadLogo } from '@/services/uploadService.js';
import { useAppContext } from '@/contexts/AppContext.jsx';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

const LogoUpload = () => {
  const { settings, refreshSettings } = useAppContext();
  const { toast } = useToast();
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(settings.logoPath || null);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileSelect = (selectedFile) => {
    setFile(selectedFile);
    setPreview(URL.createObjectURL(selectedFile));
  };

  const handleClear = () => {
    setFile(null);
    setPreview(settings.logoPath || null);
  };

  const handleUpload = async () => {
    if (!file) return;
    setIsUploading(true);
    try {
      await uploadLogo(file);
      await refreshSettings();
      toast({ title: 'Sucesso', description: 'Logo atualizado com sucesso!' });
      setFile(null);
    } catch (error) {
      toast({ title: 'Erro', description: error.message, variant: 'destructive' });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <h2 className="text-xl font-bold text-[#1a3a3a] mb-4">Logo da Empresa</h2>
      <div className="max-w-sm">
        <FileUpload
          accept="image/jpeg, image/png, image/webp, image/svg+xml"
          maxSizeMB={2}
          previewUrl={preview}
          onFileSelect={handleFileSelect}
          onClear={handleClear}
        />
        {file && (
          <Button 
            onClick={handleUpload} 
            disabled={isUploading}
            className="w-full mt-4 bg-[#4a7ba7] hover:bg-[#3a6b97] text-white"
          >
            {isUploading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
            {isUploading ? 'Salvando...' : 'Salvar Logo'}
          </Button>
        )}
      </div>
    </div>
  );
};

export default LogoUpload;
