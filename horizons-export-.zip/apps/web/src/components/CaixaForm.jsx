
import React, { useState } from 'react';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Button } from '@/components/ui/button';
import { XCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const CaixaForm = ({ isOpen, onClose, onSuccess }) => {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    valor: '',
    descricao: '',
    data: new Date().toISOString().split('T')[0],
  });

  if (!isOpen) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!currentUser) throw new Error('Usuário não autenticado');

      await pb.collection('caixa').create({
        valor: parseFloat(formData.valor),
        descricao: formData.descricao,
        data: formData.data,
        userId: currentUser.id,
      }, { $autoCancel: false });

      toast({
        title: 'Sucesso',
        description: 'Entrada de caixa registrada com sucesso!',
        variant: 'default',
      });

      setFormData({
        valor: '',
        descricao: '',
        data: new Date().toISOString().split('T')[0],
      });
      
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Erro ao criar entrada:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao registrar entrada de caixa.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all animate-in zoom-in-95 duration-200">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <h3 className="text-lg font-bold text-[#1a3a3a]">
            Nova Entrada de Caixa
          </h3>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-full hover:bg-gray-200"
          >
            <XCircle className="h-6 w-6" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-[#2c3e50]">Valor *</label>
            <div className="relative">
              <span className="absolute left-3 top-2 text-gray-500">R$</span>
              <input
                type="number"
                name="valor"
                step="0.01"
                min="0"
                required
                value={formData.valor}
                onChange={handleChange}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#4a7ba7] focus:border-transparent"
                placeholder="0.00"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-[#2c3e50]">Descrição</label>
            <input
              type="text"
              name="descricao"
              value={formData.descricao}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#4a7ba7] focus:border-transparent"
              placeholder="Ex: Aporte inicial, Venda extra..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-[#2c3e50]">Data *</label>
            <input
              type="date"
              name="data"
              required
              value={formData.data}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#4a7ba7] focus:border-transparent"
            />
          </div>
          
          <div className="flex justify-end gap-3 mt-6 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={loading}
              className="bg-[#f39c12] hover:bg-[#e67e22] text-white"
            >
              {loading ? 'Salvando...' : 'Registrar Entrada'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CaixaForm;
