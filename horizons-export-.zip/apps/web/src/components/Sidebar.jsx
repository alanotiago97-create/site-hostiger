
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { useAppContext } from '@/contexts/AppContext.jsx';
import { 
  LayoutDashboard, 
  Package, 
  Users, 
  ShoppingCart, 
  Building2, 
  Settings, 
  LogOut,
  X,
  CreditCard
} from 'lucide-react';

const Sidebar = ({ isOpen, onClose }) => {
  const { currentUser, logout, isAdmin } = useAuth();
  const { settings } = useAppContext();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard, adminOnly: true },
    { name: 'Produtos', path: '/cadastro', icon: Package, adminOnly: true },
    { name: 'Clientes', path: '/clientes', icon: Users, adminOnly: true },
    { name: 'PDV / Venda', path: '/vendas', icon: ShoppingCart, adminOnly: false },
    { name: 'Crediários', path: '/creditos', icon: CreditCard, adminOnly: false },
    { name: 'Financeiro', path: '/financeiro', icon: Building2, adminOnly: true },
    { name: 'Configurações', path: '/configuracoes', icon: Settings, adminOnly: true },
  ];

  const visibleItems = menuItems.filter(item => !item.adminOnly || isAdmin);

  const getInitials = (name) => {
    if (!name) return 'U';
    return name.substring(0, 2).toUpperCase();
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed top-0 left-0 h-screen bg-white flex flex-col border-r border-gray-200 z-50 shadow-xl lg:shadow-sm
        transition-transform duration-300 ease-in-out w-[240px]
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Header / Logo Section */}
        <div className="h-[100px] bg-[#1a3a3a] flex items-center justify-center px-4 relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-white/70 hover:text-white lg:hidden"
          >
            <X className="h-6 w-6" />
          </button>
          <div className="flex flex-col items-center gap-2">
            {settings.logoPath ? (
              <img src={settings.logoPath} alt={settings.companyName} className="h-12 object-contain bg-white/10 p-1 rounded" />
            ) : (
              <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center border-2 border-[#f39c12]">
                <span className="text-[#f39c12] font-bold text-lg">D</span>
              </div>
            )}
            <span className="text-white font-bold text-sm tracking-wider truncate w-full text-center">
              {settings.companyName.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 py-6 px-3 space-y-2 overflow-y-auto">
          {visibleItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => window.innerWidth < 1024 && onClose()}
                className={`flex items-center gap-3 px-5 py-4 rounded-xl transition-all duration-200 group ${
                  isActive 
                    ? 'bg-[#1a3a3a] text-[#f39c12] shadow-md' 
                    : 'text-[#7f8c8d] hover:bg-gray-50 hover:text-[#1a3a3a]'
                }`}
              >
                <Icon className={`h-5 w-5 ${isActive ? 'text-[#f39c12]' : 'text-gray-400 group-hover:text-[#1a3a3a]'}`} />
                <span className="font-medium text-sm">{item.name}</span>
              </Link>
            );
          })}
        </nav>

        {/* Footer / User Section */}
        <div className="p-4 border-t border-gray-100 bg-gray-50/50">
          <div className="flex items-center gap-3 mb-4 px-2">
            <div className="h-10 w-10 rounded-full bg-[#1a3a3a] flex items-center justify-center text-white font-bold shadow-sm">
              {getInitials(currentUser?.name || currentUser?.email)}
            </div>
            <div className="flex flex-col overflow-hidden">
              <span className="text-sm font-bold text-[#1a3a3a] truncate">
                {currentUser?.name || 'Usuário'}
              </span>
              <span className="text-xs text-[#7f8c8d] uppercase font-medium">
                {currentUser?.role || 'Vendedor'}
              </span>
            </div>
          </div>
          
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 bg-[#e74c3c] hover:bg-[#c0392b] text-white py-2.5 rounded-lg text-xs font-bold tracking-wide transition-colors shadow-sm"
          >
            <LogOut className="h-4 w-4" />
            SAIR DO SISTEMA
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
