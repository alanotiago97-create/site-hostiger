
import React, { useState, useEffect } from 'react';
import FileUpload from '@/components/FileUpload.jsx';

const ProductUpload = ({ onImageChange, initialImage }) => {
  const [preview, setPreview] = useState(initialImage || null);

  useEffect(() => {
    setPreview(initialImage || null);
  }, [initialImage]);

  const handleFileSelect = (file) => {
    const objectUrl = URL.createObjectURL(file);
    setPreview(objectUrl);
    onImageChange(file);
  };

  const handleClear = () => {
    setPreview(null);
    onImageChange(null);
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-[#2c3e50]">Imagem do Produto</label>
      <FileUpload
        accept="image/jpeg, image/png, image/webp"
        maxSizeMB={5}
        previewUrl={preview}
        onFileSelect={handleFileSelect}
        onClear={handleClear}
      />
    </div>
  );
};

export default ProductUpload;
