
import React, { useState, useEffect } from 'react';

const CreditPaymentForm = ({ totalAmount, onValidData }) => {
  const [formData, setFormData] = useState({
    valorPago: '',
    dataVencimento: '',
    telefoneCliente: '',
    observacoes: ''
  });

  const valorRestante = Math.max(0, totalAmount - (parseFloat(formData.valorPago) || 0));

  useEffect(() => {
    const isValid = 
      formData.valorPago !== '' && 
      parseFloat(formData.valorPago) >= 0 &&
      formData.dataVencimento &&
      formData.telefoneCliente.replace(/\D/g, '').length === 11;

    if (isValid) {
      onValidData({
        valorTotal: totalAmount,
        valorPago: parseFloat(formData.valorPago),
        valorRestante,
        dataVencimento: formData.dataVencimento,
        telefoneCliente: formData.telefoneCliente.replace(/\D/g, ''),
        observacoes: formData.observacoes
      });
    } else {
      onValidData(null);
    }
  }, [formData, totalAmount]);

  const handlePhoneChange = (e) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length <= 11) {
      let formatted = value;
      if (value.length > 2) formatted = `(${value.slice(0,2)}) ${value.slice(2)}`;
      if (value.length > 7) formatted = `(${value.slice(0,2)}) ${value.slice(2,7)}-${value.slice(7)}`;
      setFormData({ ...formData, telefoneCliente: formatted });
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  return (
    <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 space-y-4 mt-4">
      <h3 className="font-bold text-[#1a3a3a] text-sm uppercase tracking-wider">Detalhes do Crediário</h3>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-[#2c3e50] mb-1">Valor Total</label>
          <div className="px-3 py-2 bg-gray-100 rounded-md text-gray-600 font-medium">
            {formatCurrency(totalAmount)}
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-[#2c3e50] mb-1">Valor Pago (Entrada) *</label>
          <input
            type="number"
            min="0"
            step="0.01"
            value={formData.valorPago}
            onChange={(e) => setFormData({ ...formData, valorPago: e.target.value })}
            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-[#4a7ba7] outline-none"
            placeholder="0.00"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-[#2c3e50] mb-1">Valor Restante</label>
          <div className="px-3 py-2 bg-red-50 text-red-600 rounded-md font-bold">
            {formatCurrency(valorRestante)}
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-[#2c3e50] mb-1">Data de Vencimento *</label>
          <input
            type="date"
            value={formData.dataVencimento}
            onChange={(e) => setFormData({ ...formData, dataVencimento: e.target.value })}
            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-[#4a7ba7] outline-none"
          />
        </div>
      </div>

      <div>
        <label className="block text-xs font-medium text-[#2c3e50] mb-1">WhatsApp do Cliente *</label>
        <input
          type="text"
          value={formData.telefoneCliente}
          onChange={handlePhoneChange}
          placeholder="(11) 99999-9999"
          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-[#4a7ba7] outline-none"
        />
        {formData.telefoneCliente && formData.telefoneCliente.replace(/\D/g, '').length !== 11 && (
          <p className="text-xs text-red-500 mt-1">Digite um celular válido com DDD (11 dígitos)</p>
        )}
      </div>

      <div>
        <label className="block text-xs font-medium text-[#2c3e50] mb-1">Observações</label>
        <input
          type="text"
          value={formData.observacoes}
          onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
          placeholder="Ex: Parcelado em 2x"
          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-[#4a7ba7] outline-none"
        />
      </div>
    </div>
  );
};

export default CreditPaymentForm;
