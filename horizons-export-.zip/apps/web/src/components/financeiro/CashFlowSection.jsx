
import React, { useState } from 'react';
import { Edit, Trash2, ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CashFlowSection = ({ transactions, onDelete, onEdit, isAdmin }) => {
  const [filterType, setFilterType] = useState('all'); // 'all', 'in', 'out'

  const filteredTransactions = transactions.filter(t => {
    if (filterType === 'in') return t.type === 'Entrada';
    if (filterType === 'out') return t.type === 'Saída';
    return true;
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden mb-8">
      <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-xl font-bold text-[#1a3a3a]">Fluxo de Caixa Unificado</h2>
        
        <div className="flex bg-gray-200 p-1 rounded-lg">
          <button
            onClick={() => setFilterType('all')}
            className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${filterType === 'all' ? 'bg-white shadow text-gray-900' : 'text-gray-600 hover:text-gray-900'}`}
          >
            Todos
          </button>
          <button
            onClick={() => setFilterType('in')}
            className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${filterType === 'in' ? 'bg-white shadow text-green-600' : 'text-gray-600 hover:text-green-600'}`}
          >
            Entradas
          </button>
          <button
            onClick={() => setFilterType('out')}
            className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${filterType === 'out' ? 'bg-white shadow text-red-600' : 'text-gray-600 hover:text-red-600'}`}
          >
            Saídas
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Data</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Descrição</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Categoria</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Tipo</th>
              <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Valor</th>
              <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredTransactions.length === 0 ? (
              <tr>
                <td colSpan="6" className="px-6 py-8 text-center text-gray-500">
                  Nenhuma movimentação encontrada para os filtros atuais.
                </td>
              </tr>
            ) : (
              filteredTransactions.map((t) => (
                <tr key={`${t.source}-${t.id}`} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {formatDate(t.date)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">
                    {t.description || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {t.category || 'Geral'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
                      t.type === 'Entrada' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {t.type === 'Entrada' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                      {t.type}
                    </span>
                  </td>
                  <td className={`px-6 py-4 whitespace-nowrap text-right text-sm font-bold ${
                    t.type === 'Entrada' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {t.type === 'Entrada' ? '+' : '-'}{formatCurrency(t.amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {isAdmin && (
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => onDelete(t.id, t.source)}
                          className="text-red-400 hover:text-red-600 p-1.5 hover:bg-red-50 rounded-full transition-colors"
                          title="Excluir"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CashFlowSection;
