
import React from 'react';
import { Calendar, Search, CreditCard } from 'lucide-react';

const FinancialFilters = ({ filters, onFilterChange }) => {
  const handleChange = (key, value) => {
    onFilterChange({ ...filters, [key]: value });
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow-md border border-gray-100 mb-8 sticky top-20 z-20 flex flex-col md:flex-row gap-4 items-center justify-between">
      {/* Period Selector */}
      <div className="relative w-full md:w-auto flex-1 md:flex-none">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Calendar className="h-4 w-4 text-gray-400" />
        </div>
        <select
          value={filters.period}
          onChange={(e) => handleChange('period', e.target.value)}
          className="w-full pl-10 pr-8 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none"
        >
          <option value="today">Hoje</option>
          <option value="week">Esta Semana</option>
          <option value="month">Este Mês</option>
          <option value="year">Este Ano</option>
          <option value="all">Todo o Período</option>
        </select>
      </div>

      {/* Search Field */}
      <div className="relative w-full md:w-auto flex-1">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-4 w-4 text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Buscar por descrição..."
          value={filters.search}
          onChange={(e) => handleChange('search', e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      {/* Payment Method Filter */}
      <div className="relative w-full md:w-auto flex-1 md:flex-none">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <CreditCard className="h-4 w-4 text-gray-400" />
        </div>
        <select
          value={filters.paymentMethod}
          onChange={(e) => handleChange('paymentMethod', e.target.value)}
          className="w-full pl-10 pr-8 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none"
        >
          <option value="all">Todos os Pagamentos</option>
          <option value="Dinheiro">Dinheiro</option>
          <option value="PIX">PIX</option>
          <option value="Cartão Crédito">Cartão Crédito</option>
          <option value="Cartão Débito">Cartão Débito</option>
        </select>
      </div>
    </div>
  );
};

export default FinancialFilters;
