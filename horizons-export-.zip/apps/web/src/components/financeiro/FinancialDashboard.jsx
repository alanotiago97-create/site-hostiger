
import React from 'react';
import { TrendingUp, TrendingDown, Star, Wallet } from 'lucide-react';

const FinancialDashboard = ({ stats }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {/* Total Vendido */}
      <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-[#10b981]/10 rounded-lg text-[#10b981]">
            <TrendingUp className="h-6 w-6" />
          </div>
        </div>
        <p className="text-gray-500 text-sm font-medium uppercase tracking-wider">Total Vendido</p>
        <p className="text-2xl font-bold text-[#1a3a3a] mt-1">{formatCurrency(stats.totalSales)}</p>
      </div>

      {/* Total Despesas */}
      <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-[#ef4444]/10 rounded-lg text-[#ef4444]">
            <TrendingDown className="h-6 w-6" />
          </div>
        </div>
        <p className="text-gray-500 text-sm font-medium uppercase tracking-wider">Total Despesas</p>
        <p className="text-2xl font-bold text-[#1a3a3a] mt-1">{formatCurrency(stats.totalExpenses)}</p>
      </div>

      {/* Lucro Líquido */}
      <div className="bg-gradient-to-br from-[#3b82f6] to-[#2563eb] rounded-xl p-6 shadow-lg hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 text-white transform md:-translate-y-2">
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-white/20 rounded-lg text-white">
            <Star className="h-8 w-8" />
          </div>
        </div>
        <p className="text-blue-100 text-sm font-medium uppercase tracking-wider">Lucro Líquido</p>
        <p className="text-3xl font-bold text-white mt-1">{formatCurrency(stats.profit)}</p>
      </div>

      {/* Saldo em Caixa */}
      <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-[#6b7280]/10 rounded-lg text-[#6b7280]">
            <Wallet className="h-6 w-6" />
          </div>
        </div>
        <p className="text-gray-500 text-sm font-medium uppercase tracking-wider">Saldo em Caixa</p>
        <p className="text-2xl font-bold text-[#1a3a3a] mt-1">{formatCurrency(stats.cashBalance)}</p>
      </div>
    </div>
  );
};

export default FinancialDashboard;
