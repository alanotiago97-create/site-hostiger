
export const formatPhone = (phone) => {
  const cleanPhone = phone.replace(/\D/g, '');
  return cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;
};

export const generateMessage = (clientName, amount, dueDate) => {
  return `Olá ${clientName}, seu pagamento de R$ ${amount} vence em ${dueDate}. Por favor, regularize.`;
};

export const generateWhatsAppLink = (phone, message) => {
  const formattedPhone = formatPhone(phone);
  return `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
};
