
import apiServerClient from '@/lib/apiServerClient';

export const createCredit = async (creditData) => {
  const response = await apiServerClient.fetch('/credits', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(creditData),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Falha ao criar crediário');
  }
  
  return response.json();
};

export const getCredits = async (status = '') => {
  const url = status ? `/credits?status=${status}` : '/credits';
  const response = await apiServerClient.fetch(url);
  
  if (!response.ok) {
    throw new Error('Falha ao buscar crediários');
  }
  
  return response.json();
};

export const updateCredit = async (id, updateData) => {
  const response = await apiServerClient.fetch(`/credits/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updateData),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Falha ao atualizar crediário');
  }
  
  return response.json();
};

export const getAlerts = async () => {
  const response = await apiServerClient.fetch('/credits/alertas');
  
  if (!response.ok) {
    throw new Error('Falha ao buscar alertas');
  }
  
  return response.json();
};
