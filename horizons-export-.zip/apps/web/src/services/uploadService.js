
import apiServerClient from '@/lib/apiServerClient';

export const uploadProductImage = async (file) => {
  const formData = new FormData();
  formData.append('image', file);
  
  const response = await apiServerClient.fetch('/products/upload', {
    method: 'POST',
    body: formData,
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Falha ao fazer upload da imagem');
  }
  
  return response.json();
};

export const uploadLogo = async (file) => {
  const formData = new FormData();
  formData.append('logo', file);
  
  const response = await apiServerClient.fetch('/settings/logo', {
    method: 'POST',
    body: formData,
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Falha ao fazer upload do logo');
  }
  
  return response.json();
};

export const getSettings = async () => {
  const response = await apiServerClient.fetch('/settings/logo');
  if (!response.ok) {
    throw new Error('Falha ao carregar configurações');
  }
  return response.json();
};
