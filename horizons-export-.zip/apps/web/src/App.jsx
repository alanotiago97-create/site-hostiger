
import React from 'react';
import { Route, Routes, BrowserRouter as Router, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/AuthContext.jsx';
import { AppProvider } from '@/contexts/AppContext.jsx';
import ScrollToTop from '@/components/ScrollToTop.jsx';
import ProtectedRoute from '@/components/ProtectedRoute.jsx';
import SidebarLayout from '@/components/SidebarLayout.jsx';
import LoginPage from '@/pages/LoginPage.jsx';
import Dashboard from '@/pages/Dashboard.jsx';
import VendasPage from '@/pages/VendasPage.jsx';
import CadastroPage from '@/pages/CadastroPage.jsx';
import ClientesPage from '@/pages/ClientesPage.jsx';
import FinanceiroPage from '@/pages/FinanceiroPage.jsx';
import ConfiguracoesPage from '@/pages/ConfiguracoesPage.jsx';
import CreditosPage from '@/pages/CreditosPage.jsx';
import { Toaster } from '@/components/ui/toaster.jsx';

const AppRoutes = () => {
  const { isAuthenticated } = useAuth();

  return (
    <Routes>
      <Route 
        path="/login" 
        element={<LoginPage />} 
      />
      
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute requireAdmin={true}>
            <SidebarLayout>
              <Dashboard />
            </SidebarLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/vendas"
        element={
          <ProtectedRoute>
            <SidebarLayout>
              <VendasPage />
            </SidebarLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/creditos"
        element={
          <ProtectedRoute>
            <SidebarLayout>
              <CreditosPage />
            </SidebarLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/cadastro"
        element={
          <ProtectedRoute requireAdmin={true}>
            <SidebarLayout>
              <CadastroPage />
            </SidebarLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/clientes"
        element={
          <ProtectedRoute requireAdmin={true}>
            <SidebarLayout>
              <ClientesPage />
            </SidebarLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/financeiro"
        element={
          <ProtectedRoute requireAdmin={true}>
            <SidebarLayout>
              <FinanceiroPage />
            </SidebarLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/configuracoes"
        element={
          <ProtectedRoute requireAdmin={true}>
            <SidebarLayout>
              <ConfiguracoesPage />
            </SidebarLayout>
          </ProtectedRoute>
        }
      />
      
      <Route path="/" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <Router>
          <ScrollToTop />
          <AppRoutes />
          <Toaster />
        </Router>
      </AppProvider>
    </AuthProvider>
  );
}

export default App;
