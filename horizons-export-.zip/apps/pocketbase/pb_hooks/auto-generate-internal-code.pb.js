/// <reference path="../pb_data/types.d.ts" />
onRecordCreate((e) => {
  // Only generate if internalCode is not already set
  if (!e.record.get("internalCode")) {
    // Generate unique SKU: SKU-{timestamp}-{random}
    const timestamp = new Date().getTime();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    const sku = "SKU-" + timestamp + "-" + random;
    e.record.set("internalCode", sku);
  }
  e.next();
}, "products");