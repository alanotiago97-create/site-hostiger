/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("users");
  collection.createRule = "@request.auth.role = \"admin\"";
  collection.updateRule = "id = @request.auth.id || @request.auth.role = \"admin\"";
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("users");
  collection.createRule = "";
  collection.updateRule = "id = @request.auth.id";
  return app.save(collection);
})
