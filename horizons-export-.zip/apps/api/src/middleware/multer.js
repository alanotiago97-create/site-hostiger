import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Create multer storage configuration
 * @param {string} uploadDir - Directory to store uploads (relative to project root)
 * @returns {object} Multer storage configuration
 */
function createStorage(uploadDir) {
  const fullPath = path.join(__dirname, '../../..', uploadDir);

  // Ensure directory exists
  if (!fs.existsSync(fullPath)) {
    fs.mkdirSync(fullPath, { recursive: true });
  }

  return multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, fullPath);
    },
    filename: (req, file, cb) => {
      const timestamp = Date.now();
      const random = Math.random().toString(36).substring(2, 8);
      const ext = path.extname(file.originalname);
      const filename = `${timestamp}-${random}${ext}`;
      cb(null, filename);
    },
  });
}

/**
 * Create multer file filter
 * @param {array} allowedMimes - Array of allowed MIME types
 * @returns {function} Filter function
 */
function createFileFilter(allowedMimes) {
  return (req, file, cb) => {
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Invalid file type. Allowed types: ${allowedMimes.join(', ')}`));
    }
  };
}

/**
 * Create multer instance for products upload
 */
export const uploadProducts = multer({
  storage: createStorage('uploads/products'),
  fileFilter: createFileFilter(['image/jpeg', 'image/png', 'image/webp']),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
});

/**
 * Create multer instance for logo upload
 */
export const uploadLogo = multer({
  storage: createStorage('uploads/logo'),
  fileFilter: createFileFilter(['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml']),
  limits: {
    fileSize: 2 * 1024 * 1024, // 2MB
  },
});
