import logger from '../utils/logger.js';

class WhatsAppService {
  constructor(phoneNumberId, accessToken) {
    this.phoneNumberId = phoneNumberId;
    this.accessToken = accessToken;
    this.baseUrl = 'https://graph.instagram.com/v18.0';
  }

  async sendMessage(recipientPhoneNumber, message) {
    const url = `${this.baseUrl}/${this.phoneNumberId}/messages`;

    const payload = {
      messaging_product: 'whatsapp',
      to: recipientPhoneNumber,
      type: 'text',
      text: {
        preview_url: false,
        body: message,
      },
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.accessToken}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`WhatsApp API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    logger.info(`WhatsApp message sent to ${recipientPhoneNumber}`, { messageId: data.messages[0].id });
    return data;
  }

  async sendTemplate(recipientPhoneNumber, templateName, templateLanguage = 'en', parameters = []) {
    const url = `${this.baseUrl}/${this.phoneNumberId}/messages`;

    const payload = {
      messaging_product: 'whatsapp',
      to: recipientPhoneNumber,
      type: 'template',
      template: {
        name: templateName,
        language: {
          code: templateLanguage,
        },
      },
    };

    if (parameters.length > 0) {
      payload.template.components = [
        {
          type: 'body',
          parameters: parameters.map(param => ({ type: 'text', text: param })),
        },
      ];
    }

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.accessToken}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`WhatsApp API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    logger.info(`WhatsApp template sent to ${recipientPhoneNumber}`, { messageId: data.messages[0].id });
    return data;
  }

  async sendMediaMessage(recipientPhoneNumber, mediaUrl, mediaType = 'image', caption = null) {
    const url = `${this.baseUrl}/${this.phoneNumberId}/messages`;

    const payload = {
      messaging_product: 'whatsapp',
      to: recipientPhoneNumber,
      type: mediaType,
      [mediaType]: {
        link: mediaUrl,
      },
    };

    if (caption && mediaType === 'image') {
      payload[mediaType].caption = caption;
    }

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.accessToken}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`WhatsApp API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    logger.info(`WhatsApp media message sent to ${recipientPhoneNumber}`, { messageId: data.messages[0].id });
    return data;
  }

  async sendInteractiveMessage(recipientPhoneNumber, messageBody, buttons) {
    const url = `${this.baseUrl}/${this.phoneNumberId}/messages`;

    const payload = {
      messaging_product: 'whatsapp',
      to: recipientPhoneNumber,
      type: 'interactive',
      interactive: {
        type: 'button',
        body: {
          text: messageBody,
        },
        action: {
          buttons: buttons.map((button, index) => ({
            type: 'reply',
            reply: {
              id: `btn_${index}`,
              title: button,
            },
          })),
        },
      },
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.accessToken}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`WhatsApp API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    logger.info(`WhatsApp interactive message sent to ${recipientPhoneNumber}`, { messageId: data.messages[0].id });
    return data;
  }

  formatDateForMessage(date) {
    // Use standard JavaScript toLocaleDateString() instead of Intl
    // This avoids any scope or linting issues with the Intl object
    const dateObj = new Date(date);
    return dateObj.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  formatTimeForMessage(date) {
    // Use standard JavaScript toLocaleTimeString() for time formatting
    const dateObj = new Date(date);
    return dateObj.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  }
}

export default WhatsAppService;
