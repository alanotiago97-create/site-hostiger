import PocketBase from 'pocketbase';
import logger from '../utils/logger.js';

class PocketBaseService {
  constructor() {
    this.pb = new PocketBase(process.env.POCKETBASE_URL);
    this.isAuthenticated = false;
  }

  /**
   * Authenticate with PocketBase admin account
   */
  async authenticate() {
    if (this.isAuthenticated) {
      return;
    }

    try {
      await this.pb.admins.authWithPassword(
        process.env.POCKETBASE_ADMIN_EMAIL,
        process.env.POCKETBASE_ADMIN_PASSWORD
      );
      this.isAuthenticated = true;
      logger.info('PocketBase authenticated successfully');
    } catch (error) {
      logger.error('PocketBase authentication failed:', error.message);
      throw new Error('Failed to authenticate with PocketBase');
    }
  }

  /**
   * Get settings record
   */
  async getSettings() {
    await this.authenticate();
    try {
      const records = await this.pb.collection('settings').getFullList();
      return records.length > 0 ? records[0] : null;
    } catch (error) {
      logger.error('Error fetching settings:', error.message);
      throw new Error('Failed to fetch settings');
    }
  }

  /**
   * Update settings record
   */
  async updateSettings(id, data) {
    await this.authenticate();
    try {
      const updated = await this.pb.collection('settings').update(id, data);
      return updated;
    } catch (error) {
      logger.error('Error updating settings:', error.message);
      throw new Error('Failed to update settings');
    }
  }

  /**
   * Create credit record
   */
  async createCredit(data) {
    await this.authenticate();
    try {
      const created = await this.pb.collection('creditos').create(data);
      return created;
    } catch (error) {
      logger.error('Error creating credit:', error.message);
      throw new Error('Failed to create credit record');
    }
  }

  /**
   * Get credit by ID with expanded relations
   */
  async getCredit(id) {
    await this.authenticate();
    try {
      const record = await this.pb.collection('creditos').getOne(id, {
        expand: 'vendaId,clienteId',
      });
      return record;
    } catch (error) {
      logger.error('Error fetching credit:', error.message);
      throw new Error('Failed to fetch credit');
    }
  }

  /**
   * List all credits with optional filters
   */
  async listCredits(filters = {}) {
    await this.authenticate();
    try {
      let query = '';

      if (filters.status) {
        query += `status = "${filters.status}"`;
      }

      if (filters.clienteId) {
        query += query ? ` && clienteId = "${filters.clienteId}"` : `clienteId = "${filters.clienteId}"`;
      }

      const records = await this.pb.collection('creditos').getFullList({
        filter: query || undefined,
        expand: 'vendaId,clienteId',
        sort: '-created',
      });

      return records;
    } catch (error) {
      logger.error('Error listing credits:', error.message);
      throw new Error('Failed to list credits');
    }
  }

  /**
   * Update credit record
   */
  async updateCredit(id, data) {
    await this.authenticate();
    try {
      const updated = await this.pb.collection('creditos').update(id, data);
      return updated;
    } catch (error) {
      logger.error('Error updating credit:', error.message);
      throw new Error('Failed to update credit');
    }
  }

  /**
   * Get credits due soon or overdue
   */
  async getAlertCredits() {
    await this.authenticate();
    try {
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const todayStr = today.toISOString().split('T')[0];
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      // Get credits that are due today or tomorrow, or overdue
      const records = await this.pb.collection('creditos').getFullList({
        filter: `status != "pago" && dataVencimento <= "${tomorrowStr}"`,
        expand: 'vendaId,clienteId',
        sort: 'dataVencimento',
      });

      // Add status indicators
      return records.map((record) => {
        const dueDate = new Date(record.dataVencimento);
        const isOverdue = dueDate < today;
        const isDueToday = dueDate.toDateString() === today.toDateString();
        const isDueTomorrow = dueDate.toDateString() === tomorrow.toDateString();

        return {
          ...record,
          alertStatus: isOverdue ? 'overdue' : isDueToday ? 'due_today' : 'due_soon',
          daysUntilDue: Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24)),
        };
      });
    } catch (error) {
      logger.error('Error fetching alert credits:', error.message);
      throw new Error('Failed to fetch alert credits');
    }
  }
}

export default new PocketBaseService();
