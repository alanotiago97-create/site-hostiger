import express from 'express';
import { uploadLogo } from '../middleware/multer.js';
import PocketBaseService from '../services/PocketBaseService.js';
import logger from '../utils/logger.js';

const router = express.Router();

/**
 * POST /settings/logo
 * Upload and update company logo
 */
router.post('/logo', uploadLogo.single('logo'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const logoPath = `/uploads/logo/${req.file.filename}`;

  // Get current settings
  const settings = await PocketBaseService.getSettings();

  if (!settings) {
    throw new Error('Settings record not found in PocketBase');
  }

  // Update settings with new logo path
  await PocketBaseService.updateSettings(settings.id, {
    logoPath,
  });

  logger.info(`Logo updated: ${logoPath}`);

  res.json({
    success: true,
    logoPath,
  });
});

/**
 * GET /settings/logo
 * Retrieve current logo path and company name
 */
router.get('/logo', async (req, res) => {
  const settings = await PocketBaseService.getSettings();

  if (!settings) {
    throw new Error('Settings record not found');
  }

  res.json({
    logoPath: settings.logoPath || null,
    companyName: settings.companyName || null,
  });
});

export default router;
