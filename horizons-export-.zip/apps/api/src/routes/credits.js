import express from 'express';
import PocketBaseService from '../services/PocketBaseService.js';
import WhatsAppService from '../services/WhatsAppService.js';
import logger from '../utils/logger.js';

const router = express.Router();

/**
 * Validate phone format (11 digits)
 */
function validatePhone(phone) {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length !== 11) {
    throw new Error('Phone must have 11 digits');
  }
}

/**
 * Validate date format (YYYY-MM-DD)
 */
function validateDate(dateStr) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!regex.test(dateStr)) {
    throw new Error('Date must be in YYYY-MM-DD format');
  }
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) {
    throw new Error('Invalid date');
  }
}

/**
 * Validate amount (positive number)
 */
function validateAmount(amount) {
  const num = parseFloat(amount);
  if (isNaN(num) || num <= 0) {
    throw new Error('Amount must be a positive number');
  }
}

/**
 * Calculate credit status based on payment and due date
 */
function calculateStatus(valorPago, valorRestante, dataVencimento) {
  if (valorRestante <= 0) {
    return 'pago';
  }

  const dueDate = new Date(dataVencimento);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  if (dueDate < today) {
    return 'vencido';
  }

  if (valorPago > 0) {
    return 'parcial';
  }

  return 'pendente';
}

/**
 * POST /credits
 * Create new credit record
 */
router.post('/', async (req, res) => {
  const {
    vendaId,
    clienteId,
    valorTotal,
    valorPago = 0,
    valorRestante,
    dataVencimento,
    telefoneCliente,
    observacoes = '',
  } = req.body;

  // Validate required fields
  if (!vendaId || !clienteId || !valorTotal || !dataVencimento || !telefoneCliente) {
    return res.status(400).json({
      error: 'Missing required fields: vendaId, clienteId, valorTotal, dataVencimento, telefoneCliente',
    });
  }

  // Validate amounts
  validateAmount(valorTotal);
  validateAmount(valorPago);
  validateAmount(valorRestante);

  // Validate phone
  validatePhone(telefoneCliente);

  // Validate date
  validateDate(dataVencimento);

  // Validate amounts consistency
  const total = parseFloat(valorTotal);
  const paid = parseFloat(valorPago);
  const remaining = parseFloat(valorRestante);

  if (Math.abs(total - (paid + remaining)) > 0.01) {
    return res.status(400).json({
      error: 'valorTotal must equal valorPago + valorRestante',
    });
  }

  // Calculate status
  const status = calculateStatus(paid, remaining, dataVencimento);

  const creditData = {
    vendaId,
    clienteId,
    valorTotal: total,
    valorPago: paid,
    valorRestante: remaining,
    dataVencimento,
    telefoneCliente,
    status,
    observacoes,
  };

  const created = await PocketBaseService.createCredit(creditData);

  logger.info(`Credit created: ${created.id}`);

  res.status(201).json(created);
});

/**
 * GET /credits
 * List all credits with optional filters
 */
router.get('/', async (req, res) => {
  const { status, clienteId } = req.query;

  const filters = {};
  if (status) filters.status = status;
  if (clienteId) filters.clienteId = clienteId;

  const credits = await PocketBaseService.listCredits(filters);

  res.json(credits);
});

/**
 * PUT /credits/:id
 * Update credit status and payment
 */
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { status, valorPago } = req.body;

  // Get current credit
  const credit = await PocketBaseService.getCredit(id);

  if (!credit) {
    return res.status(404).json({ error: 'Credit not found' });
  }

  const updateData = {};

  // Update status if provided
  if (status) {
    const validStatuses = ['pendente', 'parcial', 'pago', 'vencido'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
      });
    }
    updateData.status = status;
  }

  // Update payment if provided
  if (valorPago !== undefined) {
    validateAmount(valorPago);
    const paid = parseFloat(valorPago);

    if (paid > credit.valorTotal) {
      return res.status(400).json({
        error: 'valorPago cannot exceed valorTotal',
      });
    }

    updateData.valorPago = paid;
    updateData.valorRestante = credit.valorTotal - paid;

    // Auto-calculate status if not explicitly provided
    if (!status) {
      updateData.status = calculateStatus(paid, updateData.valorRestante, credit.dataVencimento);
    }
  }

  const updated = await PocketBaseService.updateCredit(id, updateData);

  logger.info(`Credit updated: ${id}`);

  res.json(updated);
});

/**
 * GET /credits/alertas
 * List credits due soon or overdue
 */
router.get('/alertas', async (req, res) => {
  const alerts = await PocketBaseService.getAlertCredits();

  // Add WhatsApp information for each alert
  const alertsWithWhatsApp = alerts.map((alert) => {
    try {
      const whatsappInfo = WhatsAppService.createWhatsAppAlert(
        alert.telefoneCliente,
        alert.expand?.clienteId?.nome || 'Cliente',
        alert.valorRestante,
        alert.dataVencimento
      );

      return {
        ...alert,
        whatsapp: whatsappInfo,
      };
    } catch (error) {
      logger.warn(`Could not generate WhatsApp info for credit ${alert.id}: ${error.message}`);
      return alert;
    }
  });

  res.json(alertsWithWhatsApp);
});

export default router;
