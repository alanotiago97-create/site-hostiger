export default async (req, res) => {
    res.json({
        status: 'ok',
    });
};
