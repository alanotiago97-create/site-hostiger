import express from 'express';
import { uploadProducts } from '../middleware/multer.js';
import logger from '../utils/logger.js';

const router = express.Router();

/**
 * POST /products/upload
 * Upload product image
 */
router.post('/upload', uploadProducts.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const imagePath = `/uploads/products/${req.file.filename}`;

  logger.info(`Product image uploaded: ${imagePath}`);

  res.json({
    success: true,
    imagePath,
    message: 'Product image uploaded successfully',
  });
});

export default router;
