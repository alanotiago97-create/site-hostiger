import { Router } from 'express';
import healthCheck from './health-check.js';
import productsRouter from './products.js';
import settingsRouter from './settings.js';
import creditsRouter from './credits.js';

const router = Router();

export default () => {
  router.get('/health', healthCheck);
  router.use('/products', productsRouter);
  router.use('/settings', settingsRouter);
  router.use('/credits', creditsRouter);

  return router;
};
