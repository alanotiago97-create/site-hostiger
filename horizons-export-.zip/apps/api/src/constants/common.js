const NodeEnv = {
	Development: 'development',
	Production: 'production',
};

export { NodeEnv };
